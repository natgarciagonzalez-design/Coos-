# BookMind

Aplicación de biblioteca y estudio con importación de PDF/ePub y generación de preguntas con IA. Conserva el diseño original de BookMind.

## Requisitos

- Node.js 18 o superior.
- Una clave de API de OpenAI configurada de forma privada en el servidor para activar la generación con IA.

## Iniciar en Windows (PowerShell)

1. Abre esta carpeta en una terminal.
2. Configura la clave en la terminal (no la pegues en `index.html` ni la publiques):

```powershell
$env:OPENAI_API_KEY="TU_CLAVE_API"
node server.mjs
```

3. Abre `http://localhost:3000` en el navegador.

## Iniciar en macOS o Linux

```bash
export OPENAI_API_KEY="TU_CLAVE_API"
node server.mjs
```

Después abre `http://localhost:3000`.

También puedes definir `OPENAI_MODEL` para seleccionar un modelo disponible en tu cuenta.

## Funciones

- Importación de archivos PDF y ePub (hasta 50 MB).
- Extracción del texto para lectura y estudio.
- Almacenamiento local de libros y preguntas en el navegador.
- Generación de preguntas y respuestas basadas en el texto del libro mediante el servidor y la API de OpenAI.
- Revisión, edición y selección de preguntas antes de guardarlas.
- Tarjetas de estudio, progreso, filtros y modo claro/oscuro.

## Importante

La clave de API debe permanecer en el servidor y no debe subirse a GitHub. El HTML por sí solo puede importar y guardar los libros, pero la función de IA necesita que el servidor esté encendido y tenga una clave válida. El contenido de libros se envía al proveedor de IA al solicitar el cuestionario. Usa únicamente libros y archivos que tengas derecho a procesar.

Los PDF escaneados como imágenes pueden no contener texto seleccionable y necesitarían OCR; esta versión informa ese caso en lugar de inventar contenido.
